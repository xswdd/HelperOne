-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 11, 2022 at 08:40 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `home`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `type` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`type`) VALUES
('plumber'),
('mechanic'),
('architect'),
('electrician'),
('AC'),
('AC2'),
('car');

-- --------------------------------------------------------

--
-- Table structure for table `hello`
--

CREATE TABLE `hello` (
  `userid` int(50) NOT NULL,
  `plumber` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `helper`
--

CREATE TABLE `helper` (
  `hid` int(11) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `phone` bigint(10) NOT NULL,
  `type` varchar(50) NOT NULL,
  `area` varchar(255) NOT NULL,
  `password` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `helper`
--

INSERT INTO `helper` (`hid`, `firstname`, `lastname`, `phone`, `type`, `area`, `password`) VALUES
(29, 'Manav', 'Arora', 6353410352, 'architect', 'fire station', '22222222'),
(18, 'manthan', 'modi', 6359822773, 'mechanic', 'radhanpur', '22222222'),
(27, 'Shikhar', 'Sharma', 7043619625, 'plumber', 'palavasna', '22222222'),
(31, 'suresh', 'chachu', 7900079079, 'mechanic', 'adipur', '22222222'),
(32, 'hello', 'world', 8080808080, 'AC', 'college', '22222222'),
(21, 'manthan', 'bhavsar', 8745985698, 'plumber', 'arvind baug', '22222222'),
(30, 'Manish', 'Balani', 9001111006, 'electrician', 'sursagar', '22222222'),
(26, 'Shubham', 'Rastogi', 9173901019, 'electrician', 'nagalpur', '22222222'),
(17, 'ishika', 'jain', 9265779586, 'plumber', 'police headquarter', '22222222'),
(16, 'hiro', 'don', 9328596342, 'architect', 'dmart', '22222222'),
(13, 'Aum', 'Thanky', 9426867678, 'plumber', 'Stadium', '22222222'),
(22, 'amit', 'rana', 9428662468, 'mechanic', 'railway colony', '22222222'),
(28, 'Lakhan', 'Rastogi', 9429742564, 'mechanic', 'nagalpur', '22222222'),
(20, 'nihal', 'mn', 9586718258, 'electrician', 'manav ashram', '22222222'),
(24, 'Dharmik', 'Shah', 9632589632, 'plumber', 'Navrang Ground', '22222222'),
(25, 'Om', 'Patel', 9654741258, 'mechanic', 'Biladi Baug', '22222222'),
(15, 'raghu', 'baby', 9664427205, 'mechanic', 'ongc', '22222222'),
(33, 'gaurav', 'mohit', 9664560737, 'car', 'manav ashram', '22222222'),
(19, 'sahil', 'solu', 9727756690, 'architect', 'biladi baug', '22222222'),
(14, 'abhi', 'sharma', 9879879874, 'electrician', 'somnath', '22222222');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `uid` int(11) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` bigint(10) NOT NULL,
  `area` varchar(50) NOT NULL,
  `password` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`uid`, `firstname`, `lastname`, `email`, `phone`, `area`, `password`) VALUES
(3, 'Shobhit', 'Mendiratta', 'shobuy11@gmail.com', 8140104757, 'Nagalpur', '11111111'),
(1, 'Gaurav', 'Kumar', 'gbilandani72@gmail.com', 9664560737, 'Biladi-baug', '11111111'),
(4, 'Sonu', 'Sood', 'sonu.abc@gmail.com', 9874569874, 'lokhandvala', '11111111'),
(5, 'Salman', 'Khan', 'kill.deer@gmail.com', 9897198971, 'Jail Road', '11111111');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `helper`
--
ALTER TABLE `helper`
  ADD PRIMARY KEY (`phone`),
  ADD UNIQUE KEY `hid` (`hid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`phone`),
  ADD UNIQUE KEY `uid` (`uid`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `helper`
--
ALTER TABLE `helper`
  MODIFY `hid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
